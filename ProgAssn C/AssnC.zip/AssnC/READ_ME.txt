I replaced all read and writes with the SSL equivilants. 


COMPILE INSTRUCTIONS:
gcc -Wall -o server SSL_server.c -L/usr/lib -lssl -lcrypto
gcc -Wall -o client SSL_client.c -L/usr/lib -lssl -lcrypto
gcc -Wall -o dir SSL_dir.c -L/usr/lib -lssl -lcrypto

HOW TO RUN:
IN 3 TERMINALS, DO EACH CMD IN ONE TERMINAL IN THIS ORDER
./dir
./server NAME_OF_SERVER PORT_NUM
./client