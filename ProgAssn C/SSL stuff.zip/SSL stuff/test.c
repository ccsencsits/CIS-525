#include <stdio.h>
#include <stdlib.h>
#include <openssl/x509_vfy.h>
#include <openssl/x509.h>
#include <openssl/pem.h>


void check_certificate_validity(X509*);

int main(){
	//X509* cert;
	//cert = X509_new();
	printf("certificate done\n");
	FILE* fp;
	fp = fopen("certificate.pem", "r");
	if (fp == NULL){
		printf("something's fucky with the file pointer\n");
		return -1;
	}
	X509* cert = PEM_read_X509(fp, NULL, NULL, NULL);
	if (cert == NULL){
		printf("borked the cert\n");
		return -1;
	}
	check_certificate_validity(cert);
	return 0;
}

void check_certificate_validity(X509* certificate){
	int status;
	X509_STORE_CTX *ctx;
	ctx = X509_STORE_CTX_new();
	X509_STORE *store = X509_STORE_new();

	X509_STORE_add_cert(store, certificate);
	X509_STORE_CTX_init(ctx, store, certificate, NULL);

	status = X509_verify_cert(ctx);
	if (status == 1)
		printf("good");
	else
		printf("bad");
}
